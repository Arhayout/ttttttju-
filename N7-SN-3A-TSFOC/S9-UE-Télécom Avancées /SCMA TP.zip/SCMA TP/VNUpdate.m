function [VtoCUpdate, App] = VNUpdate(Apriori,CtoV,dv, N)
% Variable node update
% CtoV is the ordered version of incoming messages in VNs
% Outputs:
% - 
[M,Ne]=size(CtoV);
App=zeros(M,N);
for nn=0:N-1%apriri computation
App(:,nn+1)=Apriori(:,nn+1).*prod(CtoV(:,dv*nn+1:dv*(nn+1)),2);
end
VtoCUpdate=max(exp(log(kron(App,ones(1,dv)))-log(CtoV)),0);%Compute extrinsic messages
NormCst=sum(VtoCUpdate);%compute normalisation constant
VtoCUpdate=VtoCUpdate/diag(NormCst);%Normalization
NormCst=sum(App);
App=App/diag(NormCst);
end