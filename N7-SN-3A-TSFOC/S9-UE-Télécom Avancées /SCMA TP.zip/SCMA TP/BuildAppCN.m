function [AppCN]=BuildAppCN(VtoC,K,dc)

[M,Ne]=size(VtoC);
AppCN=zeros(M^dc,K);
for k=1:K
    localAppVector=VtoC(:,(k-1)*dc+1:k*dc);%Take local app vector
    CumAppVectortmp=log(localAppVector(:,dc));
    for d=1:dc-1
        CumAppVectortmp= kron( log(localAppVector(:,dc-d)),ones(M^(d),1))+kron(ones(M,1),CumAppVectortmp);
    end
    AppCN(:,k)=exp(CumAppVectortmp);
end

end