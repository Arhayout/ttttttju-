function [ CNMappingMatrix ] = ComputeMappingMatrix(CB,TG,dc)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
[K,M,N]=size(CB);

%Create the multidimensionnal mapping to be applied at each chek node
CNMappingMatrix=zeros(M,dc,K);
for k=1:K
    index=find(TG(k,:)~=0);
    CBtmp=squeeze(CB(k,:,:));%
    CNMappingMatrix(:,:,k)=CBtmp(:,index);
end
end

