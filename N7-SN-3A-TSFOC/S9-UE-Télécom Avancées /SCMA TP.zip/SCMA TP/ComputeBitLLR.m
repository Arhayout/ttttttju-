function [LLRs] = ComputeBitLLR(SymbApp)
%Compute bit LLRs
%   
[M,N]=size(SymbApp);
BinaryTable=de2bi((0:M-1)','left-msb');
LLRs=zeros(log2(M),N);
LLRs=log((1-BinaryTable')*SymbApp)-log(BinaryTable'*SymbApp);
end

