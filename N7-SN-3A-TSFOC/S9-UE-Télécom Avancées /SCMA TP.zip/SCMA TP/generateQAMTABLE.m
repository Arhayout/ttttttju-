M = 4; %Modulation order 
hMod = comm.QPSKModulator('BitInput',true);
hModSymb = comm.QPSKModulator('BitInput',false);
hDemodHD = comm.QPSKDemodulator('BitOutput',true,...
    'DecisionMethod', 'Hard decision');
QAMLUT=step(hModSymb,[0 1 2 3].');
QAMLUT2=step(hDemodHD,QAMLUT);
BinaryMapping=reshape(QAMLUT2, 2, numel(QAMLUT2)/log2(M))';

QAMLUT=[BinaryMapping, QAMLUT];

