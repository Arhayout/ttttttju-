function [SymbApp] = SCMABPDecoder(y,N0,hlocal,TG,M,Nbiter,CNMappingMatrix, BinaryIndicator, Apriori, Interleaver)
%BP decoder
%Recovering Graph structure
[K,N]=size(TG);
dv=sum(TG(:,1));
dc=sum(TG(1,:));
NbEdges=nnz(TG);
%Initialization
VtoCUpdate=1/M*ones(M,NbEdges);
%Apriori=1/M*ones(M,N);%considered here for code concatenation
PartialMetricsMatrix = ComputeMetrics(TG,y,N0,hlocal,CNMappingMatrix);
for niter=1:Nbiter
% Check node update
    AppCN=BuildAppCN(VtoCUpdate(:,Interleaver),K,dc);
    [CtoVupdate] = CNUpdate(PartialMetricsMatrix, BinaryIndicator, VtoCUpdate(:,Interleaver),AppCN,dc);%CN update
    CtoVupdate(:,Interleaver)=CtoVupdate;%reordering
    [VtoCUpdate, App] = VNUpdate(Apriori,CtoVupdate,dv, N);%VN update
end
SymbApp=App;
end

