close all;
clear all;

% Codebooks loading
%%%
[CB]=LoadCodebook('LDS-QPSK');          
K = size(CB, 1); % number of orthogonal resources
M = size(CB, 2); % number of codewords in each codebook
V = size(CB, 3); % number of users (layers)
N = 1; % SCMA signals in frame

%CHannel parameter
EbN0 = (0:14);
SNR  = EbN0 + 10*log10(log2(M)*V/K);
Capa =zeros(V, length(SNR));
Nerr  = zeros(V, length(SNR));
Nbits = zeros(V, length(SNR));
BER   = zeros(V, length(SNR));

maxNumErrs = 5;
maxNumBits = 1e7;
Niter      = 30;

%
%Build Tanner Graph Adjency Matrix
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
TG=double((squeeze(CB(:,1,:))~=0+1i*0));%could be any k for k=1 to M 
[Interleaver]=Buildinterleaver(TG);
Reff=log2(M)*V/K;% Spectral efficiency
dv=sum(TG(:,1));
dc=sum(TG(1,:));
disp('Tanner Graph')
disp(TG);
param=sprintf('The associated Tanner graph is a regular (d_v,d_c)=(%d,%d) Tanner Graph \nThe system overload is %d \nThe spectral efficiency is %d',sum(TG(:,1)),sum(TG(1,:)),V/K,Reff);
disp(param); %N/K is equivalent rate of the underlaying non binary LDGM scheme
spy(sparse(TG))
%initialization
[ CNMappingMatrix ] = ComputeMappingMatrix(CB,TG,dc);
[ MappingSymbolIndictator, BinaryIndicator ] = ComputeSymbolIndicator(M,dc);

for k = 1:length(SNR)

    N0 = 1/(10^(SNR(k)/10)); % noise power
    count=0;
    while ((min(Nerr(:,k)) < maxNumErrs) && (Nbits(1,k) < maxNumBits))
        %Bits generation
        x = randi([0 M-1], V, N); % log2(M)-bit symbols
        
        h = 1/sqrt(2)*(randn(K, V, N)+1j*randn(K, V, N)); % Rayleigh channel
        % h=ones(K,V,N);%AWGN channel
        s = scmaenc(x, CB, h); % joint encoding and fading channel propagation
        y = awgn(s, SNR(k));
        
        Apriori=1/M*(ones(M,V)-eps);%considered here for code concatenation
        [SymbApp] = SCMABPDecoder(y,N0,h,TG,M,Niter,CNMappingMatrix, BinaryIndicator,Apriori, Interleaver);
        [LLRs] = ComputeBitLLR(SymbApp);
        LLRs=LLRs(:);
         r    = de2bi(x, log2(M), 'left-msb');
        data = zeros(log2(M)*N, V);
        for kk = 1:V
            data(:,kk) = reshape(downsample(r, V, kk-1).',[],1);
        end

        % LLR to bit conversion
        datadec = reshape((LLRs <= 0), [log2(M) N*V]).';
        datar   = zeros(log2(M)*N, V);
        for kk = 1:V
            datar(:,kk) = reshape(downsample(datadec, V, kk-1).', [], 1);
        end

        err        = sum(xor(data, datar));
        Nerr(:,k)  = Nerr(:,k) + err.';
        
        Nbits(:,k) = Nbits(:,k) + log2(M)*N;
        
        mean(Nerr./Nbits)
       
        count=count+1;
        display(count);
    end
    BER(:,k) = Nerr(:,k)./Nbits(:,k);
    k;
end
