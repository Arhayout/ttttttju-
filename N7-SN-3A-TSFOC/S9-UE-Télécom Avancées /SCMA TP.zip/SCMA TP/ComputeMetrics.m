function [ PartialMetricsMatrix ] = ComputeMetrics(TG,y,N0, hlocal,CNMappingMatrix)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

[M,dc,K]=size(CNMappingMatrix);

%Create the multidimensionnal mapping to be applied at each chek node
PartialMetricsMatrix=zeros(M^dc,K);
[ htmp ] = ComputeLocalHMatrix(TG,dc,hlocal);
for k=1:K
    
    PartialMetricstmp=htmp(k,dc)* CNMappingMatrix(:,dc,k);
    for d=1:dc-1
        PartialMetricstmp= kron(htmp(k,dc-d)* CNMappingMatrix(:,dc-d,k),ones(M^(d),1))+kron(ones(M,1),PartialMetricstmp);
    end
    PartialMetricsMatrix(:,k)=-abs(y(k)-PartialMetricstmp).^2/N0;
end

end