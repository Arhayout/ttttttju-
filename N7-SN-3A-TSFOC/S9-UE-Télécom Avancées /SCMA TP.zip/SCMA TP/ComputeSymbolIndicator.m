function [ MappingSymbolIndictator, BinaryIndicator ] = ComputeSymbolIndicator(M,dc)
%%Compute the array table to be used to compute metrics
 BinaryIndicator=zeros(M^dc,M*dc);
 MappingSymbolIndictatorInit=(0:M-1)';
 BinaryIndicatorInit=[1, zeros(1, M-1)]';
 MappingSymbolIndictator=MappingSymbolIndictatorInit;
 BinaryIndicatortmp=BinaryIndicatorInit;
    for dd=1:dc-1
        MappingSymbolIndictator=[ kron(MappingSymbolIndictatorInit,ones(M^(dd),1)), kron(ones(M,1),MappingSymbolIndictator)] ;%[Extented vesion, duplicated version]
        BinaryIndicatortmp=[ kron(BinaryIndicatorInit,ones(M^(dd),1)), kron(ones(M,1),BinaryIndicatortmp)] ;%[Extented vesion, duplicated version]
    end
    for dd=1:dc
        for m=1:M
            BinaryIndicator(:,m+(dd-1)*M)=circshift(BinaryIndicatortmp(:,dd), (m-1)*(M)^(dc-dd));
        end
    end
end