function [Interleaver] = Buildinterleaver(TG)

%If the numering is 1 to NbEdge from the VN ...
%perspective, Interleaver gives the interleaving vector for messages
%ordered in the CN perspectives
NbEdge=nnz(TG);
NumIndexInterleaver=(1:NbEdge);
Index=find(TG~=0);
TG2=TG;
TG2(Index)=NumIndexInterleaver;
Interleaver=nonzeros(TG2')';


end