function [ LocalH ] = ComputeLocalHMatrix(TG,dc,hlocal)
%UNTITLED Summary of this function goes here
%   h is a K x N matrix of channel gains for the considered SCMA codeword
index=find(TG'~=0);
[K,N]=size(TG);
htmp=hlocal.';
LocalH=reshape(htmp(index),[dc,K]).';
end

