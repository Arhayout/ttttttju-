function [CB] = BuildGeneticCodebook(TG,M,gamma, phi, E)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
[K,N]=size(TG);
CB=zeros(K,M,N);
alpha=sqrt(E*gamma./(gamma+1));
beta=sqrt(E*1./(gamma+1));
for n=1:N
CBtmp=diag(phi(n:n+1))*[alpha(n) -beta(n) beta(n) -alpha(n); -beta(n) -alpha(n)  alpha(n) beta(n)];
index=find(TG(:,n)~=0);
CB(index,:,n)=CBtmp;
end
end

