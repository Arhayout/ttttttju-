function [CtoVupdate] = CNUpdate(PartialMetricsMatrix, BinaryIndicator ,VtoC, AppCN,dc)
% Check node update
% Vtoc is the matrix of probabilities from the CN point of view (interleaved version)
[M,Ne]=size(VtoC);
CtoVupdate=zeros(M,Ne);
%buidd matrix of App for CNs, to be update at each iteration
K=floor(Ne/dc);
%AppCN=BuildAppCN(VtoC,K,dc);


for k=1:K
    %for d=1:dc
        d2=PartialMetricsMatrix(:,k);%recover partial metrics
        x=d2+log(AppCN(:,k));%take apriori from VN
        NbReplica=dc*M;
        xtmp=BinaryIndicator.*repmat(x,[1 NbReplica]);
        index=find(xtmp<0);
        CtoVupdatetmp=log_sum_exp(reshape(xtmp(index),M^(dc-1), length(xtmp(index))/M^(dc-1)));
        CtoVupdate(:,(k-1)*dc+1:k*dc)=reshape(CtoVupdatetmp,M,length(CtoVupdatetmp)/M)-log(VtoC(:,(k-1)*dc+1:k*dc));
    %end
end
CtoVupdate=max(exp(CtoVupdate),0);
end
